# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 13:41:15 2022

@author: pyan
"""

import numpy as np
import yfinance as yf
from scipy.stats import norm
from matplotlib.pyplot import *
ticker='IBM'
begdate='2015-1-1'
enddate='2015-11-9'
p = yf.download(ticker, begdate, enddate)['Adj Close']
ret = p.pct_change()
[n,bins,patches] = hist(ret, 100)
mu = np.mean(ret)
sigma = np.std(ret)
x = norm.pdf(bins, mu, sigma)
plot(bins, x, color='red', lw=2)
title("IBM return distribution")
xlabel("Returns")
ylabel("Frequency")
show()