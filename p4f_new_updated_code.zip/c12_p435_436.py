# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 19:58:17 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf
import matplotlib.pyplot as plt

# Step 1: input area
ticker='MSFT'          # input value 1
begdate='1926-1-1'     # input value 2
enddate='2013-12-31'   # input value 3
n_simulation=5000      # input value 4
#
# Step 2: retrieve price data and estimate log returns
x=yf.download(ticker,begdate,enddate)
#
# Step 3: estimate annual returns
x['logret'] =np.log(x['Adj Close'].pct_change()+1)
x['yyyy']=x.index.year    
retAnnual=np.exp(x['logret'].groupby(x['yyyy']).sum())-1
#

n_obs=retAnnual.shape[0]
# Step 4: estimate distribution with replacement
np.random.seed(123577)
final=[]
#
for i in range(0,n_simulation):
    k=int(np.random.uniform(low=0,high=n_obs,size=1))
    final.append(retAnnual.values[k])
    
# step 5: graph
plt.title('Mean return distribution: number of simulations ='+str(n_simulation))
plt.xlabel('Mean return')
plt.ylabel('Frequency')
mean_annual=round(np.mean(retAnnual),4)
#plt.figtext(0.15,1500,'mean annual='+str(mean_annual))
plt.hist(final,normed=True)
plt.show()
