# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 16:53:49 2022

@author: pyan
"""

import numpy as np
from scipy import stats
import yfinance as yf
#
ticker='IBM'
begdate='2012-1-1'
enddate='2016-12-31'
p =yf.download(ticker, begdate, enddate)['Adj Close']
ret = p.pct_change().dropna()

print('ticker=',ticker,'W-test, and P-value')
print(stats.shapiro(ret))



