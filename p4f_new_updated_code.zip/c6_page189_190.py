# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 14:14:27 2022

@author: pyan
"""

from scipy import stats
import yfinance as yf
#
begdate='2012-1-1'
enddate='2016-12-31'
ticker='MSFT'
p =yf.download(ticker, begdate)['Adj Close']
retIBM = p.pct_change().dropna()
#
ticker2='^GSPC'
p2 =yf.download(ticker2, begdate)['Adj Close']
retMkt = p2.pct_change().dropna()
#
(beta,alpha,r_value,p_value,std_err)=stats.linregress(retMkt,retIBM)
print(alpha,beta)
print("R-squared=", r_value**2)
print("p-value =", p_value)
