# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 16:33:00 2022

@author: pyan
"""

import  yfinance as yf
ticker='IBM'
begdate='2013-1-1'
enddate='2013-11-9'
x =yf.download(ticker, begdate, enddate)
ret=x['Adj Close'].pct_change()