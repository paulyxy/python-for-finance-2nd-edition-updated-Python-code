# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 10:09:12 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf

tickers=('IBM','WMT','C')   # tickers
begdate='2012-1-1'          # beginning date
enddate='2016-12-31'        # ending date
n=len(tickers)              # number of observations
A=1                         # risk preference
#
def ret_f(ticker,begdate,enddte):
    x=yf.download(ticker,begdate,enddate)
    ret =x['Adj Close'].pct_change()
    return ret
#
def myUtilityFunction(ret,A=1):
    meanDaily=np.mean(ret)
    varDaily=np.var(ret)
    meanAnnual=(1+meanDaily)**252
    varAnnual=varDaily*252
    return meanAnnual- 0.5*A*varAnnual
 #
for i in np.arange(n):
    ret=ret_f(tickers[i],begdate,enddate)
    print(tickers[i], myUtilityFunction(ret,A))
"""

IBM 1.0031388172073432
WMT 1.0555598115386973
C 1.1707279852296824

"""