# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 14:39:51 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf
import matplotlib.pyplot as plt

begdate='2012-1-1'
enddate='2016-12-31'
ticker='IBM'
def ret_f(ticker): # function 1
    x = yf.download(ticker,begdate,enddate)
    x['ret']=x['Adj Close'].pct_change()
    x=x.drop(['Open','High','Low','Volume','Adj Close','Close'],axis=1)
    return x
#    
a=ret_f(ticker)
b=ret_f("^GSPC")
c=pd.merge(a,b,left_index=True, right_index=True).dropna()
print(c.head())
mean=np.mean(c)
print(mean)
cov=np.dot(c.T,c)
print(cov)

"""
print(mean)
ret_x    0.000081
ret_y    0.000479
dtype: float64

cov=np.dot(c.T,c)

print(cov)
[[0.17358742 0.07238897]
 [0.07238897 0.08238055]]
"""