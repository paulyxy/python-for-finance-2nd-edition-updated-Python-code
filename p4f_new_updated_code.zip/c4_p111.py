# -*- coding: utf-8 -*-
"""
Created on Thu Dec  8 16:03:52 2022

@author: pyan
"""

"""
old

Use the functions contained in various Python modules, such as the function
called quotes_historical_yahoo_ohlc() in the matplotlib.finance
submodule


-->

new

Use the functions contained in various Python modules, such as the function
called download () in the yfinance Python module. 
submodule










"""