# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 19:43:08 2022

@author: pyan
"""

import yfinance as yf

# Step 1: input area
tickers=('IBM','WMT','C') # tickers
begdate='2012-1-1'      # beginning date
enddate='2016-12-31'    # ending date
weight=(0.2,0.5,0.3)    # weights
confidence_level=0.99   # confidence level
position=5e6            # total value
#
z=norm.ppf(confidence_level)

# Step 2: define a function
def ret_f(ticker,begdate,enddte):
    x=yf.download(ticker,begdate,enddate)
    ret=x['Adj Close'].pct_change().dropna()
    return(ret)

# Step 3
n=np.size(tickers)
final=ret_f(tickers[0],begdate,enddate)
for i in np.arange(1,n):
    a=ret_f(tickers[i],begdate,enddate)
    if i>0:
       final=pd.merge(final,a,left_index=True,right_index=True)
#
# Step 4: get porfolio returns
portRet=np.dot(final,weight)
portStd=np.std(portRet)
portMean=np.mean(portRet)
VaR=position*(portMean-z*portStd)

print("Holding=",position, "VaR=", round(VaR,2), "tomorrow")
#  Holding= 5000000.0 VaR= -109356.23 tomorrow
# compare
total2=0.0
i=0
for ticker in tickers:
    ret=ret_f(tickers[i],begdate,enddate)
    position2=position*weight[i]
    i+=1
    mean=np.mean(ret)
    std=np.std(ret)
    VaR=position2*(mean-z*std)
    total2+=VaR
#    
print("For ", ticker, "with a value of ", position2, "VaR=",
round(VaR,2))
print("Sum of three VaR=",round(total2,2))
"""
For  C with a value of  1500000.0 VaR= -59440.81
Sum of three VaR= -147189.6
"""


