# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 20:52:41 2022

@author: pyan
"""

import numpy as np
import yfinance as yf
from scipy import stats

#
ticker='^GSPC'
begdate='1926-1-1'
enddate='2013-12-31'
x =yf.download(ticker, begdate, enddate)
ret =x['Adj Close'].pct_change().dropna()
#
print( 'S&P500 n =',len(ret))
print( 'S&P500 mean =',round(np.mean(ret),8))
print( 'S&P500 std =',round(np.std(ret),8))
print( 'S&P500 skewness=',round(stats.skew(ret),8))
print( 'S&P500 kurtosis=',round(stats.kurtosis(ret),8))
"""

S&P500 n = 21597
S&P500 mean = 0.00028799
S&P500 std = 0.01205591
S&P500 skewness= -0.08182935
S&P500 kurtosis= 17.37738594
"""