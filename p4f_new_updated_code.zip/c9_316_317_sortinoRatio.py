# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 14:28:19 2022

@author: pyan
"""

import scipy as sp
import numpy as np
import pandas as pd
import yfinance as yf
from scipy.optimize import fmin

#
# Step 1: input area
ticker=('IBM','WMT','C')  # tickers
begdate='1990-1-1'        # beginning date
enddate='2012-12-31'      # ending date
rf=0.0003                 # annual risk-free rate
#
# Step 2: define a few functions
# function 1:
def ret_annual(ticker,begdate,enddate):
    x=yf.download(ticker,begdate,enddate)
    x['logret'] =np.log(x['Adj Close'].pct_change()+1)
    x['Year']=x.index.year    
    retAnnual=np.exp(x['logret'].groupby(x['Year']).sum())-1
    return retAnnual

# function 2: estimate LPSD
def LPSD_f(returns, Rf):
    y=returns[returns-Rf<0]
    m=len(y)
    total=0.0
    for i in np.arange(m):
        total+=(y[i]-Rf)**2
    return total/(m-1)
# function 3: estimate Sortino
def sortino(R,w):
    mean_return=np.mean(R,axis=0)
    ret = np.array(mean_return)
    LPSD=LPSD_f(R,rf)
    return (np.dot(w,ret) - rf)/LPSD

# function 4: for given n-1 weights, return a negative sharpe ratio
def negative_sortino_n_minus_1_stock(w):
    w2=np.append(w,1-sum(w))
    return -sortino(R,w2) # using a return matrix here!!!!!!

# Step 3: generate a return matrix (annul return)
n=len(ticker) # number of stocks
x2=ret_annual(ticker[0],begdate,enddate)
for i in ticker[1:]:
    x_=ret_annual(i,begdate,enddate)
    x2=pd.merge(x2,x_,left_index=True,right_index=True)
    
# using scipy array format
R = np.array(x2)
print('Efficient porfolio (mean-variance) :ticker used')
print(ticker)
print('Sortino ratio for an equal-weighted portfolio')
equal_w=np.ones(n, dtype=float) * 1.0 /n
print(equal_w)
print(sortino(R,equal_w))
# for n stocks, we could only choose n-1 weights
w0= np.ones(n-1, dtype=float) * 1.0 /n
w1 = fmin(negative_sortino_n_minus_1_stock,w0)
final_w = np.append(w1, 1 - sum(w1))
final_sortino = sortino(R,final_w)
print ('Optimal weights are ')
print (final_w)
print ('final Sortino ratio is ')
print(final_sortino)
"""
Efficient porfolio (mean-variance) :ticker used
('IBM', 'WMT', 'C')
Sortino ratio for an equal-weighted portfolio
[0.33333333 0.33333333 0.33333333]
1.559524781239201
Warning: Maximum number of function evaluations has been exceeded.
Optimal weights are 
[-4.04574902e+43  3.41085097e+43  6.34898056e+42]
final Sortino ratio is 
4.489468032072898e+42

"""

 
 