# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 17:57:53 2022

@author: pyan
"""

import yfinance as yf
x = yf.download("IBM",'2016-1-1','2016-1-21')
print(x[0:4])