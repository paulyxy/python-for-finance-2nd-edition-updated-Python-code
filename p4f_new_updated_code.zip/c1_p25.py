# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 21:20:51 2022

@author: pyan
"""

import re
import yfinance as yf
#
ticker='dell'
#
outfile=ticker+".csv"
begdate='2013-1-1'
enddate='2016-11-9'
df=yf.download(ticker,begdate,enddate)
df.to_csv(outfile)


