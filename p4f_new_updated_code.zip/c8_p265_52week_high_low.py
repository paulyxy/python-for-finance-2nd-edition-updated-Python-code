# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 09:14:30 2022

@author: pyan
52-week high-low trading strategy

"""

import numpy as np
import yfinance as yf
from datetime import datetime
from dateutil.relativedelta import relativedelta

#
ticker='IBM'
begdate='2021-01-01'
enddate='2021-12-31'
#
p =yf.download(ticker, begdate, enddate)['Adj Close']
high=max(p)
low=min(p)
print(" Today, Price High Low, % from low ")
print( p[-1], high, low, round((p[-1]-low)/(high-low)*100,2))
"""
 Today, Price High Low, % from low 
127.58259582519531 134.43115234375 102.83460235595703 78.32
"""