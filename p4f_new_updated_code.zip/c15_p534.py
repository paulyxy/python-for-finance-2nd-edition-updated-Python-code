# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 21:16:08 2022

@author: pyan
"""

import numpy as np
import yfinance as yf
import matplotlib.pyplot as plt

#
ticker='^GSPC'
begdate='1987-11-1'
enddate='2006-12-31'
#
x =yf.download(ticker, begdate, enddate)
ret =x['Adj Close'].pct_change()
#
plt.title('Illustration of volatility clustering (S&P500)')
plt.ylabel('Daily returns')
plt.xlabel('Date')
plt.plot(ret)
plt.show()