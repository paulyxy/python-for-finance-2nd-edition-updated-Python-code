# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 11:17:40 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import scipy as sp
import yfinance as yf
import matplotlib.pyplot as plt
from numpy.linalg import inv, pinv

# 1. Code for input area:
begYear,endYear = 2001,2013
stocks=['IBM','WMT','AAPL','C','MSFT']

#2. Code for defining two functions:
def ret_monthly(ticker): # function 1
    year1=str(begYear)+"-1-1"
    year2=str(endYear)+"-12-31"
    x=yf.download(ticker,year1,year2)
    x['logret'] =np.log(x['Adj Close'].pct_change()+1)
    x['yyyymm']=x.index.year*100+x.index.month    
    retMonthly=np.exp(x['logret'].groupby(x['yyyymm']).sum())-1
    return retMonthly

# function 2: objective function
def objFunction(W, R, target_ret):
    stock_mean=np.mean(R,axis=0)
    port_mean=np.dot(W,stock_mean)     # portfolio mean
    cov=np.cov(R.T)                    # var-cov matrix
    port_var=np.dot(np.dot(W,cov),W.T) # portfolio variance
    penalty = 2000*abs(port_mean-target_ret)# penalty 4 deviation
    return np.sqrt(port_var) + penalty  # objective function

#3. Code for generating a return matrix R:
R0=ret_monthly(stocks[0])   # starting from 1st stock
for stock in stocks[1:]:    # merge with other stocks
    x=ret_monthly(stock)
    R0=pd.merge(R0,x,left_index=True,right_index=True)
#
R=np.array(R0)

#4. Code for estimating optimal portfolios for a given return:
out_mean,out_std,out_weight=[],[],[]
stockMean=np.mean(R,axis=0)
for r in np.linspace(np.min(stockMean),np.max(stockMean),num=100):
    W = np.ones([n_stock])/n_stock # starting from equal weights
    b_ = [(0,1)
    for i in range(n_stock)] # bounds, here no short
    c_ = ({'type':'eq', 'fun': lambda W: sum(W)-1. })#constraint
    result=sp.optimize.minimize(objFunction,W,(R,r),method='SLSQP',constraints=c_, bounds=b_)
    if not result.success:
        BaseException(result.message)
    out_mean.append(round(r,4)) # 4 decimal places
    std_=round(np.std(np.sum(R*result.x,axis=1)),6)
    out_std.append(std_)
    out_weight.append(result.x)

#5. Code for plotting the efficient frontier:
plt.title('Efficient Frontier')
plt.xlabel('Standard Deviation of the porfolio (Risk))')
plt.ylabel('Return of the portfolio')
plt.figtext(0.5,0.75,str(n_stock)+' stock are used: ')
plt.figtext(0.5,0.7,' '+str(stocks))
plt.figtext(0.5,0.65,'Time period: '+str(begYear)+'----'+str(endYear))
plt.plot(out_std,out_mean,'--')
plt.show()


