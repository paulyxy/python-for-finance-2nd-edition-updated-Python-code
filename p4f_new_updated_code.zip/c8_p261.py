# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 16:57:07 2022

@author: pyan
"""
import numpy as np
import yfinance as yf
from scipy import stats

ticker='^GSPC'
begdate='1926-1-1'
enddate='2016-12-31'
p = yf.download(ticker, begdate, enddate)['Adj Close']
ret = p.pct_change().dropna()
print( 'S&P500 n =',len(ret))
print( 'S&P500 mean =',round(np.mean(ret),8))
print('S&P500 std =',round(np.std(ret),8))
print('S&P500 skewness=',round(stats.skew(ret),8))
print('S&P500 kurtosis=',round(stats.kurtosis(ret),8))

"""
S&P500 n = 22354
S&P500 mean = 0.0002882
S&P500 std = 0.01195134
S&P500 skewness= -0.08475569
S&P500 kurtosis= 17.42920217
"""