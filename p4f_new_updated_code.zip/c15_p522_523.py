# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 20:47:30 2022

@author: pyan
"""
import numpy as np
import yfinance as yf
from scipy import stats
#
ticker='IBM'
begdate='2009-1-1'
enddate='2013-12-31'
x =yf.download(ticker, begdate, enddate)
ret =x['Adj Close'].pct_change().dropna()
std_annual=np.std(ret)*np.sqrt(252)
print('volatility (std)=',round(std_annual,4))
# volatility (std)= 0.2093
print('ticker=',ticker,'W-test, and P-value')
print(stats.shapiro(ret))
 # ticker= IBM W-test, and P-value
 # ShapiroResult(statistic=0.9295356273651123, pvalue=7.514182534434207e-24)