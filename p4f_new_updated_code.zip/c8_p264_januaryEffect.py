# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 08:58:08 2022

@author: pyan

Testing the January effect
"""

import numpy as np
import scipy as sp
import pandas as pd
import yfinance as yf
from datetime import datetime
ticker='IBM'
begdate='1962-1-1'
enddate='2016-12-31'
x =yf.download(ticker, begdate, enddate)
x['logret']=np.log(x['Adj Close'].pct_change()+1)
x['yyyymm']=x.index.year*100+x.index.month
#
y=np.exp(x['logret'].groupby(x.yyyymm).sum()-1)
retM=y.groupby(y.index).sum()
ret_Jan=retM[retM.index-np.int0(retM.index/100)*100==1]
ret_others=retM[retM.index-np.int0(retM.index/100)*100!=1]
print(sp.stats.ttest_ind(ret_Jan.values,ret_others.values))
#Ttest_indResult(statistic=2.0398666719147247, pvalue=0.04176245705647582)
