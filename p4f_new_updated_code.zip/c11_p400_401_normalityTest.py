# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 19:31:02 2022

@author: pyan
"""

import numpy as np
import yfinance as yf
from scipy import stats
#
ticker='MSFT'
begdate='2012-1-1'
enddate='2016-12-31'

x =yf.download(ticker, begdate, enddate)
ret =x['Adj Close'].pct_change().dropna()

print('ticker=',ticker,'W-test, and P-value')
print(stats.shapiro(ret))
print( stats.anderson(ret))

#ShapiroResult(statistic=0.9165628552436829, pvalue=9.448209248545018e-26)
#AndersonResult(statistic=14.728628421727763, critical_values=array([0.574, 0.654, 0.785, 0.915, 1.089]), significance_level=array([15. , 10. ,  5. ,  2.5,  1. ]))
