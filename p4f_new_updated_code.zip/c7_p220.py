# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 15:46:20 2022

@author: pyan

yyyymm
201201    0.033817
201202    0.025421
201203    0.060591
201204   -0.007524
201205   -0.064574
Name: logret, dtype: float64
"""
import numpy as np
import pandas as pd
import yfinance as yf
import statsmodels.api as sm
ticker='IBM'
begdate='2012-1-1'
enddate='2016-12-31'
df= yf.download(ticker, begdate, enddate)
df['logret']=np.log(df["Adj Close"].pct_change()+1)
df['yyyymm']=df.index.year*100+df.index.month
df=df.dropna()
retM=pd.DataFrame(np.exp(df['logret'].groupby(df['yyyymm']).sum())-1)
#
infile='http://datayyy.com/data_pickle/ff3monthly.pkl'
ff=pd.read_pickle(infile)

ff['yyyymm']=ff.index.year*100+ff.index.month
final=retM.merge(ff,left_on=retM.index,right_on='yyyymm')

y=final['logret']
x=final[['MKT_RF','SMB','HML']]
x=sm.add_constant(x)
results=sm.OLS(y,x).fit()
print(results.summary())
