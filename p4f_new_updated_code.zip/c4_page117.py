# -*- coding: utf-8 -*-
"""
Created on Sun Dec  4 19:24:12 2022

@author: pyan
"""

import yfinance as yf
ticker='IBM'
begdate='2015-1-1'
enddate='2015-11-9'
df = yf.download(ticker, begdate, enddate)
ret= df['Adj Close'].pct_change()
