# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 15:57:09 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf
from scipy.stats import norm
#
# input area
ticker='IBM'           # input 1
n_shares=1000          # input 2
confidence_level=0.99  # input 3
begdate='2012-2-7'     # input 4
enddate='2017-2-7'     # input 5

z=norm.ppf(1-confidence_level)
x=yf.download(ticker,begdate,enddate)
print(x.head(1))
ret = x['Adj Close'].pct_change()
#
position=n_shares*x['Close'][0]
std=np.std(ret)
#
VaR=position*z*std
print("Holding=",position, "VaR=", round(VaR,4), "tomorrow")
# Holding= 184847.03063964844 VaR= -5047.6918 tomorrow