# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 09:25:04 2022

@author: pyan
"""

import numpy as np
import yfinance as yf

ticker='IBM'
begdate="2013-9-1"
enddate="2013-11-11"
data= yf.download(ticker, begdate, enddate)
p=data['Adj Close']
d=np.diff(p)
cov_=np.cov(d[:-1],d[1:])
if cov_[0,1]<0:
    print("Roll spread for ", ticker, 'is', round(2*np.sqrt(-cov_[0,1]),3))
else:
    print("Cov is positive for ",ticker, 'positive', round(cov_[0,1],3))
# Roll spread for  IBM is 0.771