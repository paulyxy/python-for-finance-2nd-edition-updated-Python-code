# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 10:33:03 2022

@author: pyan
"""


import numpy as np
import pandas as pd
import yfinance as yf
from scipy.optimize import fmin

# 1. Code for input area:
ticker=('IBM','WMT','C')   # tickers
begdate='1990-1-1'         # beginning date
enddate='2012-12-31'       # ending date
rf=0.0003                  # annual risk-free rate

# Code for defining a few functions:
# function 1:
def ret_annual(ticker,begdate,enddate):
    x=yf.download(ticker,begdate,enddate)
    x['logret'] =np.log(x['Adj Close'].pct_change()+1)
    x['Year']=x.index.year    
    retAnnual=np.exp(x['logret'].groupby(x['Year']).sum())-1
    return retAnnual
#
# function 2: estimate portfolio variance
def portfolio_var(R,w):
    cor = np.corrcoef(R.T)
    std_dev=np.std(R,axis=0)
    var = 0.0
    for i in range(0,n):
        for j in range(0,n):
            var += w[i]*w[j]*std_dev[i]*std_dev[j]*cor[i, j]
    return var
#
# function 3: estimate Sharpe ratio
def sharpe(R,w):
    var = portfolio_var(R,w)
    mean_return=np.mean(R,axis=0)
    ret = np.array(mean_return)
    return (np.dot(w,ret) - rf)/np.sqrt(var)
# function 4: for given n-1 weights, return a negative sharpe ratio
def negative_sharpe_n_minus_1_stock(w):
    w2=np.append(w,1-sum(w))
    return -sharpe(R,w2) # using a return matrix here!!!!!!
#
#3. Code for generating a return matrix (annul return):
n=len(ticker) # number of stocks
x2=ret_annual(tickers[0],begdate,enddate)
#
for i in range(1,n):
    x_=ret_annual(tickers[i],begdate,enddate)
    x2=pd.merge(x2,x_,left_index=True,right_index=True)
#
# using numpy array format
R = np.array(x2)
print('Efficient porfolio (mean-variance) :ticker used')
print(ticker)
print('Sharpe ratio for an equal-weighted portfolio')
equal_w=np.ones(n, dtype=float) * 1.0 /n
print(equal_w)
print(sharpe(R,equal_w))
# 0.6337646439889694
# for n stocks, we could only choose n-1 weights
w0= np.ones(n-1, dtype=float) * 1.0 /n
w1 = fmin(negative_sharpe_n_minus_1_stock,w0)
final_w = np.append(w1, 1 - sum(w1))
final_sharpe = sharpe(R,final_w)
print ('Optimal weights are ')
print (final_w)   #[0.49670579 0.30910543 0.19418879]
print ('final Sharpe ratio is ')
print(final_sharpe)

