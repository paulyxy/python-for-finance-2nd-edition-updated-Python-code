# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 16:03:35 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf
from scipy.stats import norm


ticker='WMT'          # input 1
n_shares=50           # input 2
confidence_level=0.99 # input 3
n_days=10             # input 4
begdate='2012-1-1'    # input 5
enddate='2016-12-31'  # input 6
#
z=norm.ppf(confidence_level)
x=yf.download(ticker,begdate,enddate)
ret = x['Adj Close'].pct_change()
position=n_shares*x['Close'][0]
VaR=position*z*np.std(ret)*np.sqrt(n_days)
print(VaR)

# 233.35747801156546