# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 09:30:31 2022

@author: pyan

Amihud illiquidity 
"""

import numpy as np
import yfinance as yf

begdate='2013-10-1'
enddate='2013-10-30'
ticker='IBM' # or WMT
data= yf.download(ticker, begdate, enddate)
p=data['Adj Close']
dollar_vol=data.Volume*p
ret=p.pct_change()
illiq=np.mean(np.divide(abs(ret),dollar_vol[1:])) 
print("Aminud illiq for =",ticker,illiq) 
# Aminud illiq for = IBM 1.6882065355363383e-11
