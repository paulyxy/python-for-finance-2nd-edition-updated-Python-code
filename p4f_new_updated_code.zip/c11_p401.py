# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 19:35:43 2022

@author: pyan
"""

import numpy as np
import yfinance as yf
from scipy import stats

#
ticker='^GSPC' # ^GSPC is for S&P500
begdate='2012-1-1'
enddate='2016-12-31'
#
x =yf.download(ticker, begdate, enddate)
ret =x['Adj Close'].pct_change().dropna()
#
print('ticker=',ticker,'W-test, and P-value')
print(stats.shapiro(ret))
print( stats.anderson(ret) )

#ShapiroResult(statistic=0.9763539433479309, pvalue=1.7378370335656423e-13)

#AndersonResult(statistic=8.309231224877294, 
#critical_values=array([0.574, 0.654, 0.785, 0.915, 1.089]),
# significance_level=array([15. , 10. ,  5. ,  2.5,  1. ]))