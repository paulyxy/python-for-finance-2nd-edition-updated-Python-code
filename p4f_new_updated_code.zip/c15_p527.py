# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 20:55:23 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf
from scipy import stats
#
ticker='IBM'
begdate='2009-1-1'
enddate='2013-12-31'
x =yf.download(ticker, begdate, enddate)
x['ret']=x['Adj Close'].pct_change()
x=x.drop(columns=['Open', 'High', 'Low', 'Close', 'Adj Close', 'Volume'])
x=x.dropna()
#
infile="http://datayyy.com/data_pickle/ff3monthly.pkl"
ff=pd.read_pickle(infile)
#                  
final=pd.merge(x,ff,left_on=x.index,right_on=ff.index)
#
k=final.ret-final.RF
k2=k[k<0]
LPSD=np.std(k2)*np.sqrt(252)
print("LPSD=",LPSD)
print(' LPSD (annualized) for ', ticker, 'is ',round(LPSD,3))

"""
LPSD= 0.08889114623423829
 LPSD (annualized) for  IBM is  0.089
 """