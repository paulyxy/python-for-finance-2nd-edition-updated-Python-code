# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 13:21:13 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf
ticker='IBM'
begdate='2015-1-1'
enddate='2015-12-31'
x = yf.download(ticker, begdate)['Adj Close']
logret = np.log(x.pct_change()+1)
logret=logret.dropna()
