# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 13:04:25 2022

@author: pyan
"""

import yfinance as yf
print(dir(yf))

['Ticker', 'Tickers', '__all__', '__author__', '__builtins__', '__cached__', '__doc__',
 '__file__', '__loader__', '__name__', '__package__', '__path__', '__spec__', '__version__',
 'base', 'download', 'multi', 'pdr_override', 'set_tz_cache_location', 'shared', 'ticker', 
 'tickers', 'utils', 'version']


