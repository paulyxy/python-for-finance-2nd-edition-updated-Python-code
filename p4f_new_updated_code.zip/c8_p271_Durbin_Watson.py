# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 09:40:34 2022

@author: pyan
"""
import pandas as pd
import yfinance as yf
from scipy import stats
import statsmodels.formula.api as sm
import statsmodels.stats.stattools as tools
from  sklearn.linear_model import LinearRegression
#
begdate='2012-1-1'
enddate='2016-12-31'
#
def dailyRet(ticker,begdate,enddate):
    p =yf.download(ticker, begdate, enddate)['Adj Close']
    return p.pct_change().dropna()
#
retIBM=dailyRet('IBM',begdate,enddate)
retMKT=dailyRet('^GSPC',begdate,enddate)
model=LinearRegression()
y=np.array(retIBM)
X=np.array(retMKT).reshape(-1, 1)
result=model.fit(X,y)
result.intercept_ #Out[1012]: -0.0003417758407169231
result.coef_      #Out[1013]: array([0.88121541])
#
residuals = (y - model.predict(X))
print("Durbin Watson")
print(tools.durbin_watson(residuals))
# 1.821178951853143