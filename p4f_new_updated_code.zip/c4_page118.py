# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 13:14:10 2022

@author: pyan
"""

import numpy as np
import yfinance as yf
from scipy import stats
ticker='ibm'
begdate='2011-1-1'
enddate='2015-12-31'
df=yf.download(ticker,begdate,enddate)
ret=df['Adj Close'].pct_change()
mean=np.mean(ret)
print(' Mean ' )
print(round(mean,5))
