# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 17:01:20 2022

@author: pyan
"""


import numpy as np
import yfinance as yf
from scipy import stats
ticker='ibm'
begdate='2013-1-1'
enddate='2013-12-31'
x=yf.download(ticker,begdate,enddate)
ret=x['Adj Close'].pct_change().dropna()
print(' Mean T-value P-value ' )
print(round(np.mean(ret),5), stats.ttest_1samp(ret,0))

"""

 Mean T-value P-value 
-6e-05 Ttest_1sampResult(statistic=-0.08335301517696371, pvalue=0.9336378168694467)

"""