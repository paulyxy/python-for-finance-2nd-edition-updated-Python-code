# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 21:05:31 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf
from scipy.stats import bartlett
#
# input area
ticker='F' # stock
begdate1='1982-9-1'   # starting date for period 1
enddate1='1987-9-1'   # ending date for period 1
begdate2='1987-12-1'  # starting date for period 2
enddate2='1992-12-1'  # ending date for period 2
#
# define a function
def ret_f(ticker,begdate,enddate):
    x =yf.download(ticker, begdate, enddate)
    ret = x['Adj Close'].pct_change().dropna()
    return(ret)
#
# call the above function twice
ret1=ret_f(ticker,begdate1,enddate1)
ret2=ret_f(ticker,begdate2,enddate2)
#
# output
print('Std period #1 vs. std period #2')
print(round(np.std(ret1),6),round(np.std(ret2),6))
print('T value , p-value ')
print(bartlett(ret1,ret2))
"""

Std period #1 vs. std period #2
0.019812 0.017918
T value , p-value 
BartlettResult(statistic=12.726919808728939, pvalue=0.0003604296736268726)

"""
