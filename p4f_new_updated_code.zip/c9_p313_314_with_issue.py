# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 13:56:15 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf
import matplotlib.pyplot as plt
from scipy.optimize import fmin
#
# Step 1: input area
ticker=('IBM','WMT','C')   # tickers
begdate='1990-1-1'         # beginning date
enddate='2012-12-31'       # ending date
rf=0.0003                  # annual risk-free rate
betaGiven=(0.8,0.4,0.3)    # given beta's

# function 1:
def ret_annual(ticker,begdate,enddate):
    x=yf.download(ticker,begdate,enddate)
    x['logret'] =np.log(x['Adj Close'].pct_change()+1)
    x['Year']=x.index.year    
    retAnnual=np.exp(x['logret'].groupby(x['Year']).sum())-1
    return retAnnual
#
# function 2: estimate portfolio beta 
def portfolioBeta(betaGiven,w):
    #print("betaGiven=",betaGiven,"w=",w)
    return np.dot(betaGiven,w)
# function 3: estimate Treynor
def treynor(R,w):
    betaP=portfolioBeta(betaGiven,w)
    mean_return=np.mean(R,axis=0)
    ret = np.array(mean_return)
    return (np.dot(w,ret) - rf)/betaP
# function 4: for given n-1 weights, return a negative Sharpe ratio
def negative_treynor_n_minus_1_stock(w):
    w2=np.append(w,1-sum(w))
    return -treynor(R,w2) # using a return matrix here!!!!!!
# Step 3: generate a return matrix (annul return)
n=len(ticker) # number of stocks
x2=ret_annual(ticker[0],begdate,enddate)
for i in range(1,n):
    x_=ret_annual(ticker[i],begdate,enddate)
    x2=pd.merge(x2,x_,left_index=True,right_index=True)
# using numpy array format
R = np.array(x2)
print('Efficient porfolio (Treynor ratio) :ticker used')
print(ticker)
print('Treynor ratio for an equal-weighted portfolio')
equal_w=np.ones(n, dtype=float) * 1.0 /n
print(equal_w)
print(treynor(R,equal_w))   # 0.3175518139308392
# for n stocks, we could only choose n-1 weights
w0= np.ones(n-1, dtype=float) * 1.0 /n
w1 = fmin(negative_treynor_n_minus_1_stock,w0)
final_w = np.append(w1, 1 - sum(w1))
final_treynor = treynor(R,final_w)
print ('Optimal weights are ')
print (final_w)
print ('final Treynoe ratio is ')
print(final_treynor)



