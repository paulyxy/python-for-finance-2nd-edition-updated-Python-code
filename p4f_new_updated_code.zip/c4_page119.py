# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 13:18:43 2022

@author: pyan
"""

import yfinance as yf
import scipy.stats as stats

begdate='2013-1-1'
enddate='2016-12-9'
#
def ret_f(ticker,begdate,enddate):
    df= yf.download(ticker,begdate,enddate)
    ret=df['Adj Close'].pct_change()
    return(ret)
a=ret_f('IBM',begdate,enddate)
b=ret_f('MSFT',begdate,enddate)