# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 15:37:44 2022

@author: pyan
"""

def dailyReturn(ticker,begdate,enddate):
    import yfinance as yf
    p =yf.download(ticker, begdate,enddtae)['Adj Clse']
    return p.pct_change().dropna()