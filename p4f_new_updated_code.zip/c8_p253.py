# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 16:42:50 2022

@author: pyan
"""


import numpy as np
import pandas as pd
import yfinance as yf
#
ticker='IBM'
begdate='2016-1-2'
enddate='2017-1-9'
x =yf.download(ticker, begdate)
myName=ticker+'_adjClose'

x2=pd.DataFrame(x['Adj Close'])
x2.columns=[myName]
infile='http://datayyy.com/data_pickle/ff3daily.pkl'

ff=pd.read_pickle(infile)
final=pd.merge(x2,ff,left_index=True,right_index=True)
print(final.head())
