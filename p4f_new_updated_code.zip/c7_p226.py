# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 17:25:46 2022

@author: pyan
"""


import numpy as np
import yfinance as yf 
begdate='2012-1-1'
enddate='2016-12-31'
def ret_f(ticker,begdate,enddate):
    p = yf.download(ticker,begdate, enddate)['Adj Close']
    return(p.pct_change())
#
y=ret_f('IBM',begdate,enddate)
sharpe=np.mean(y)/np.std(y)
print(sharpe)



