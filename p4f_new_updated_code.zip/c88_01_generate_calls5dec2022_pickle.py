# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 15:09:43 2022

@author: pyan
"""

import pandas as pd
#infile="http://datayyy.com/data_txt/calls5dec2022.txt"

infile="calls23dec2022.txt"


df=pd.read_table(infile)
df.to_pickle("calls23dec2022.pickle")
