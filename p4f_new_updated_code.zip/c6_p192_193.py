# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 14:48:47 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf
from scipy import stats
from sklearn.linear_model import LinearRegression
#
def ret_f(ticker,begdate, enddate):
    p = yf.download(ticker, begdate)['Adj Close']
    return(p.pct_change())
#
begdate='2010-1-1'
enddate='2016-12-31'
y0=ret_f('IBM',begdate,enddate).dropna()
x0=ret_f('^GSPC',begdate,enddate).dropna()
#
years=np.unique(x0.index.year)

for year in years:
    if year<2022:
        x1=x0[x0.index.year==year]
        y1=y0[y0.index.year==year]
        (beta,alpha,r_value,p_value,std_err)=stats.linregress(y1.values,x1.values)
        alpha=round(alpha,8)
        beta=round(beta,3)
        r_value=round(r_value,3)
        p_vaue=round(p_value,3)
        print(year,alpha,beta,r_value,p_value)
        
        
        
     
     
     
     
   
        
        