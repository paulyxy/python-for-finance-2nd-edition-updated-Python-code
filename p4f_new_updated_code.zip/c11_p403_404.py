# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 19:38:49 2022

@author: pyan
"""

import numpy as np
import pandas as pd
import yfinance as yf
from scipy.stats import stats,norm

#
ticker='WMT'            # input 1
n_shares=500            # input 2
confidence_level=0.99   # input 3
begdate='2000-1-1'      # input 4
enddate='2016-12-31'    # input 5
#
# Method I: based on the first two moments
z=abs(norm.ppf(1-confidence_level)) 
x=yf.download(ticker,begdate,enddate)
ret = x['Adj Close'].pct_change().dropna()
position=n_shares*x['Close'][-1]
mean=np.mean(ret)
std=np.std(ret)
VaR1=position*(mean-z*std)
print("Holding=",round(position,2), "VaR1=", round(VaR1,2), "for 1 day")
# Holding= 111941.5 VaR1= -2050.83 for 1 day
#
# Modified VaR: based on 4 moments
s=stats.skew(ret)
k=stats.kurtosis(ret)
t=z+1/6.*(z**2-1)*s+1/24.*(z**3-3*z)*k-1/36.*(2*z**3-5*z)*s**2
mVaR=position*(mean-t*std)
print("Holding=",round(position,2), "modified VaR=", round(mVaR,2),"for 1 day ")
# Holding= 111941.5 modified VaR= -2276.4 for 1 day 

