# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 16:35:10 2022

@author: pyan
"""


import numpy as np
import pandas as pd
import yfinance as yf

ticker='IBM'
begdate='2013-1-1'
enddate='2013-11-9'
#
x = yf.download(ticker, begdate, enddate)
x['logret']=np.log(x['Adj Close'].pct_change()+1)
x['yyyymm']=x.index.year*100+x.index.month
#
retMonthly=np.exp(x['logret'].groupby(x['yyyymm']).sum())-1
print(retMonthly.head())


