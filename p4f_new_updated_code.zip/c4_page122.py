# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 13:39:05 2022

@author: pyan
"""

import scipy as sp
import  yfinance as yf
begdate='2013-1-1'
enddate='2015-12-31'
def ret_f(ticker,begdate,enddate):
    p = yf.download(ticker,begdate)['Adj Close']
    return(p.pct_change())
#
y=ret_f('IBM',begdate,enddate)
x=ret_f('MSFT',begdate,enddate)