# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 14:46:03 2022

@author: pyan
"""

import yfinance as yf
from scipy import stats

#
def dailyReturn(ticker,begdate,enddate):
    p = yf.download(ticker, begdate,enddate)['Adj Close']
    return p.pct_change().dropna()
#
begdate='2012-1-1'
enddate='2017-1-9'
retIBM=dailyReturn("wmt",begdate,enddate)
retMkt=dailyReturn("^GSPC",begdate,enddate)
outputs=stats.linregress(retMkt,retIBM)
print(outputs)