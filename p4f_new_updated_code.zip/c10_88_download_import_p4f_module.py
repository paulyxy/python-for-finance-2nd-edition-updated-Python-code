# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 12:46:12 2022

@author: pyan
"""

from download import download
infile="http://datayyy.com/code_py/p4f.abc"
outfile="p4f.pyc"
download(infile,outfile,replace=True)
import p4f

"""
print(dir(p4f))
['CND', 'EAR_f', 'EBITDA_value', 'IRR_f', 'IRRs_f', 'NPER', 
 'PMT', 'Rc_f', 'Rm_f', '__builtins__', '__cached__', '__doc__',
 '__file__', '__loader__', '__name__', '__package__', '__request',
 '__spec__', 'binomial_grid', 'bond_price', 'bs_call', 'bs_call_old',
 'bs_put', 'convert_B_M', 'dailyPrice', 'dailyReturn', 'delta_call', 
 'delta_put', 'duration', 'durationBond', 'fv_annuity', 'fv_f', 
 'getSpreadBasedOnCredit', 'getYahooRet', 'get_200day_moving_avg',
 'get_50day_moving_avg', 'get_52week_high', 'get_52week_low', 
 'get_EBITDA', 'get_all', 'get_avg_daily_volume', 'get_book_value',
 'get_change', 'get_dividend_per_share', 'get_dividend_yield', 
 'get_earnings_per_share', 'get_historical_prices', 'get_market_cap',
 'get_price', 'get_price_book_ratio', 'get_price_earnings_growth_ratio',
 'get_price_earnings_ratio', 'get_price_sales_ratio', 'get_short_ratio',
 'get_stock_exchange', 'get_volume', 'market_cap', 'mean', 
 'modified_duration', 'n_annuity', 'npv_f', 'payback_', 
 'payback_period', 'priceDaily', 'pvValueNperiodModel', 'pv_annuity',
 'pv_annuity_k_period_from_today', 'pv_excel', 'pv_f', 'pv_grow_perpetuity',
 'pv_growing_annuity', 'pv_perpetuity', 'pv_perpetuity_due', 
 'r_continuous', 'rateYan', 'rollSpread', 'sign', 'simpleVScompoundRate',
 'urllib']
"""


