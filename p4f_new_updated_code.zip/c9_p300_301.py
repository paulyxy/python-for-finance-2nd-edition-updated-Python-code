# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 10:24:38 2022

@author: pyan
"""


import numpy as np
import pandas as pd
import yfinance as yf
#
tickers=('IBM','WMT','C') # tickers
begdate='2012-1-1'     # beginning date
enddate='2016-12-31'   # ending date
n=len(tickers)         # number of observations
def ret_f(ticker,begdate,enddte):
    x=yf.download(ticker,begdate,enddate)
    ret =x['Adj Close'].pct_change()
    return ret
#
def meanVarAnnual(ret):
    meanDaily=np.mean(ret)
    varDaily=np.var(ret)
    meanAnnual=(1+meanDaily)**252
    varAnnual=varDaily*252
    return meanAnnual, varAnnual

print("meanAnnual, varAnnjal")
for ticker in tickers:
    ret=ret_f(ticker,begdate,enddate)
    print(ticker,meanVarAnnual(ret))
"""

IBM (1.020538250464625, 0.03479876102073496)

WMT (1.0694932658305383, 0.02786691047809525)

C (1.2086897073608733, 0.07592335190764377)


"""