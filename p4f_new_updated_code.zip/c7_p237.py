# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 17:50:46 2022

@author: pyan
"""

def sharpeRatio(ticker,begdate='2012-1-1',enddate='2016-12-31'):
    """ Objective: estimate Sharpe ratio for stock
       ticker : stock symbol
       begdate : beginning date
       enddate : ending date
        
       Example #1: sharpeRatio("ibm")
                     0.006865573345602177
     
     Example #2: date1='1990-1-1'
                 date2='2015-12-23'
                 sharpeRatio("ibm",date1,date2)
                    0.027816237037040874
     """
    import numpy as np
    import yfinance as yf
    p = yf.download(ticker,begdate, enddate)['Adj Close']
    ret=p.pct_change()
    return np.mean(ret)/np.std(ret)


