# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 14:11:32 2022

@author: pyan
"""

import datetime
import yfinance as yf
import matplotlib.pyplot as plt
from matplotlib.dates import MonthLocator,DateFormatter

ticker='AAPL'
begdate='2012-1-2'
enddate ='2013-12-4'
months= MonthLocator(range(1,13), bymonthday=1, interval=3)# 3rd month
monthsFmt = DateFormatter("%b '%Y")
x = yf.download(ticker, begdate, enddate)['Adj Close']
#
if len(x) == 0:
    print ('Found no quotes')
    raiseSystemExit
dates =x.index
closes =x
fig, ax = plt.subplots()
ax.plot_date(dates, closes, '-')
ax.xaxis.set_major_locator(months)
ax.xaxis.set_major_formatter(monthsFmt)
ax.autoscale_view()
ax.grid(True)
fig.autofmt_xdate()
plt.show()