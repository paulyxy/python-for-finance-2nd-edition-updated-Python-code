# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 15:33:24 2022

@author: pyan
"""

import yfinance as yf
ticker='c'
begdate='2016-1-1'
enddate='2017-1-9'
p =yf.download(ticker, begdate, enddate)
p.to_csv("c://temp/c.csv")
