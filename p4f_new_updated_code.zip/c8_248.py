# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 16:31:18 2022

@author: pyan
"""

import yfinance as yf
x = yf.download("IBM",'2016-1-1','2016-1-21')
print(x[0:4])