# -*- coding: utf-8 -*-
"""
Created on Wed Dec  7 21:25:20 2022

@author: pyan
"""

import datetime
import yfinance as yf
import matplotlib.pyplot as plt
from matplotlib.dates import MonthLocator,DateFormatter
#
ticker='AAPL'
begdate='2012-1-2'
enddate ='2013-12-5'

months = MonthLocator(range(1,13), bymonthday=1, interval=3) # every 3rd month
monthsFmt = DateFormatter("%b '%Y")
x = yf.download(ticker, begdate, enddate)
if len(x) == 0:
    print ('Found no quotes')
    raise SystemExit
#
dates =x.index
closes =x['Close']
fig, ax = plt.subplots()
ax.plot_date(dates, closes, '-')
ax.xaxis.set_major_locator(months)
ax.xaxis.set_major_formatter(monthsFmt)
ax.xaxis.set_minor_locator(mondays)
ax.autoscale_view()
ax.grid(True)
fig.autofmt_xdate()
